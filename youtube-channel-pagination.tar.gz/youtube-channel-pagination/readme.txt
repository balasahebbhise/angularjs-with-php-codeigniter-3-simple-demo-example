Plugin Name: Youtube Channel Pagination
Plugin URI:
Description: The plugin is show all youtube channel video with pagination.
Version: 1.0
Author: Mr. Balasaheb Bhise
Author URI:
License: GPL2

Copyright 2016 Balasaheb Bhise  (email : balasahebbhise1@gmail.com)
 
This plugin for list youtube channel video on your web site.
Website owner have to create Channel Id and api key.
and select how money video per setting form admin.

Youtube Channel Pagination Setting:-We have given from backend admin must set all setting. 

Demo youtube channel:- UCfPLDrpFPVEJBFm0woqur2A
Demo youtube API Key:- AIzaSyBKANNBOEWuI41YQKRi7f6g3M7WhecXYtk;
Default per page:- 04;