=== Youtube Channel Pagination ===
Contributors: (https://profiles.wordpress.org/balasahebbhise)
Author: Mr. Balasaheb Bhise
Tags: Youtube, Youtube Channel Pagination, Youtube Videos Pagination, Youtube Channel, Youtube Videos, Pagination, Youtube Videos pagination, gallery, Youtube API 3.
Requires at least: 4.1
Tested up to: 4.6
Stable tag: 4.6
License: GPLv2 or later
License URI: https://github.com/balasahebbhise/youtube-channel-pagination

The plugin is usefull for showing youtube channel videos with pagination.

Copyright 2016 Balasaheb Bhise  (email : balasahebbhise1@gmail.com)

== Description ==

The plugin is usefull for showing youtube channel videos with pagination.This plugin for list youtube channel video on your web site.
Website owner have to create Channel Id and api key.and select how money video per setting form admin.

== Installation ==

Upload the Youtube Channel Pagination plugin to your plugin, Activate it, then use this short code on for page [Youtube_Channel_Pagination].

== Setting ==

Youtube Channel Pagination Setting:-We have given from backend admin must set all setting. 

The website owner have to create below credential for their website.

Demo youtube channel:- UCfPLDrpFPVEJBFm0woqur2A
Demo youtube API Key:- AIzaSyBKANNBOEWuI41YQKRi7f6g3M7WhecXYtk;
Default per page:- 04;
Note: Pleas do not use above credential on production this is only for test purpose.